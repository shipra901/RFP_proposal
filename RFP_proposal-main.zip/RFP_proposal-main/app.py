# Import required libraries
import streamlit as st  # For creating the web interface
import json  # For saving/loading JSON data
import os  # For file system operations
from dotenv import load_dotenv  # For loading environment variables from .env
from rag_helper import get_similar_examples  # Retrieves similar proposal examples using FAISS+RAG
from llm import call_mistral  # Function to generate proposal from local Mistral model
from docx_writer import save_proposal_to_docx  # Saves the final proposal as a .docx file
from RFP_proposal.extract_rfp_fields import extract_rfp_json  # Extracts structured fields from uploaded RFP
from datetime import datetime  # To manage timestamps if needed

# Import evaluation functions for scoring proposals
from proposal_evaluator import (
    evaluate_quality_score_llm,  # LLM-based evaluation of proposal quality
    evaluate_win_probability_llm,  # LLM-based estimate of proposal win probability
    section_checklist,  # Verifies presence of required sections
    readability_score  # Calculates Flesch readability score
)

# Load any environment variables
load_dotenv()

# Set up Streamlit UI page
st.set_page_config(page_title="RFP Proposal Generator", layout="centered")
st.title("📄 RFP Proposal Generator")
st.markdown("Upload a new RFP file (PDF, DOCX, TXT) or manually enter details.")

# Upload file section – accept PDF, DOCX, or TXT and extract structured fields
uploaded_file = st.file_uploader("Upload RFP file (PDF, DOCX, TXT)", type=["pdf", "docx", "txt"])

if uploaded_file:
    temp_path = f"temp_{uploaded_file.name}"
    with open(temp_path, "wb") as f:
        f.write(uploaded_file.read())
    extracted_fields = extract_rfp_json(temp_path)
    os.remove(temp_path)
else:
    extracted_fields = {
        "title": "",
        "description": "",
        "scope_of_work": "",
        "budget": "",
        "deadline": "",
        "contact_email": "",
        "contact_phone": "",
        "client_name": ""
    }

# Sidebar preview
st.sidebar.header("ℹ️ Extracted Fields")
st.sidebar.write(extracted_fields)

# Manual editing or confirmation
with st.form("rfp_form"):
    title = st.text_input("RFP Title", value=st.session_state.get("title", extracted_fields["title"]))
    description = st.text_area("Project Description", value=st.session_state.get("description", extracted_fields.get("description", "")))
    scope = st.text_area("Scope of Work", value=st.session_state.get("scope", extracted_fields["scope_of_work"]))
    budget = st.text_input("Estimated Budget", value=st.session_state.get("budget", extracted_fields["budget"]))
    deadline = st.text_input("Deadline (e.g., July 30, 2025)", value=st.session_state.get("deadline", extracted_fields["deadline"]))
    contact = st.text_input("Contact Email", value=st.session_state.get("contact", extracted_fields["contact_email"]))
    phone = st.text_input("Contact Phone", value=st.session_state.get("phone", extracted_fields.get("contact_phone", "")))
    client = st.text_input("Client Name", value=st.session_state.get("client", extracted_fields.get("client_name", "")))
    submitted = st.form_submit_button("Generate Proposal")

if submitted:
    st.info("⏳ Generating your proposal...")

    rfp_input = {
        "title": title,
        "description": description,
        "scope_of_work": scope,
        "budget": budget,
        "deadline": deadline,
        "contact_email": contact,
        "contact_phone": phone,
        "client_name": client
    }
        # Save input RFP to local JSON file

    os.makedirs("data/generated_rfps", exist_ok=True)
    json_path = f"data/generated_rfps/{title.replace(' ', '_')}.json"
    with open(json_path, "w") as jf:
        json.dump(rfp_input, jf, indent=2)
        
    # Retrieve Similar Proposals for Prompt Injection

    query_text = description + " " + scope
    examples = get_similar_examples(query_text)
    # Build Prompt for Local LLM (Mistral)
    def create_prompt(rfp_input, examples):
        prompt = f"""
Generate a structured and technical proposal that directly addresses the project requirements. 
Do NOT use sales-like language such as \"we are pleased to...\" or \"we are excited to...\".

Instead, focus on:

1. What the project needs
2. How it will be executed
3. Who will do it
4. Budget
5. Timeline
6. Compliance and capabilities

Tone: Factual, professional, and client-focused. Avoid fluff.

RFP Title: {rfp_input['title']}
Scope/Description: {rfp_input['description']} {rfp_input['scope_of_work']}
Budget: {rfp_input['budget']}
Deadline: {rfp_input['deadline']}
Contact Info: {rfp_input['contact_email']}, {rfp_input['contact_phone']}, {rfp_input['client_name']}

Use the following examples from past proposals as guidance:
"""
        for idx, ex in enumerate(examples):
            prompt += f"""
--- Example {idx+1} ---
Executive Summary: {ex.get("executive_summary", "")}
Technical Approach: {ex.get("technical_approach", "")}
Team: {ex.get("team", "")}
Timeline: {ex.get("implementation_timeline", "")}
Budget Overview: {ex.get("budget_overview", "")}
"""
        prompt += "\nNow write a new proposal with all standard sections in clear structure."
        return prompt
    # Create prompt and generate proposal content
    final_prompt = create_prompt(rfp_input, examples)
    proposal_text = call_mistral(final_prompt)
    # Save the Final Proposal as a DOCX File
    file_path = save_proposal_to_docx(rfp_input["title"], proposal_text, rfp_input)

    # AI-powered evaluation
    quality_score, quality_reason = evaluate_quality_score_llm(proposal_text)
    win_prob_score, win_reason = evaluate_win_probability_llm(proposal_text, rfp_input)
    present_sections, missing_sections = section_checklist(proposal_text)
    readability = readability_score(proposal_text)
    
    # Show download buttons for proposal and input JSON
    st.download_button(
        label="📄 Download Proposal (.docx)",
        data=open(file_path, "rb"),
        file_name="proposal.docx",
        key="download_docx"
    )

    st.download_button(
        label="🗂️ Download Input JSON",
        data=open(json_path, "rb"),
        file_name="rfp_input.json",
        key="download_json"
    )

    # Display evaluation metrics
    st.subheader("📊 Proposal Evaluation")

    st.write(f"✅ **Quality Score:** {quality_score}%")
    st.caption(f"💬 {quality_reason}")

    st.write(f"🏆 **Win Probability:** {win_prob_score}%")
    st.caption(f"📌 {win_reason}")

    st.write(f"📋 **Sections Present:** {', '.join(present_sections)}")
    if missing_sections:
        st.warning(f"❌ Missing Sections: {', '.join(missing_sections)}")

    if readability is not None:
        st.write(f"📚 **Readability Score (Flesch Reading Ease):** {readability}")

