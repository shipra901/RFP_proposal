# extract_rfp_fields.py

import os
import re
import json
import docx
from PyPDF2 import PdfReader

def extract_text_from_pdf(filepath):
    text = ""
    try:
        reader = PdfReader(filepath)
        for page in reader.pages:
            text += page.extract_text() or ""
    except:
        print(f"Error reading PDF: {filepath}")
    return text

def extract_text_from_docx(filepath):
    text = ""
    try:
        doc = docx.Document(filepath)
        for para in doc.paragraphs:
            text += para.text + "\n"
    except:
        print(f"Error reading DOCX: {filepath}")
    return text

def extract_text_from_txt(filepath):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read()
    except:
        print(f"Error reading TXT: {filepath}")
        return ""

def extract_fields(text):
    fields = {}

    # Title
    title_match = re.search(r"(RFP Title|Title|Subject):\s*(.+)", text, re.IGNORECASE)
    fields["title"] = title_match.group(2).strip() if title_match else "Not found"

    # Deadline
    deadline_match = re.search(r"(Deadline|Due Date|Closing Date):\s*(.+)", text, re.IGNORECASE)
    fields["deadline"] = deadline_match.group(2).strip() if deadline_match else "Not found"

    # Budget
    budget_match = re.search(r"(Budget|Amount|Total Value):\s*\$?([\d,]+)", text, re.IGNORECASE)
    fields["budget"] = f"${budget_match.group(2).strip()}" if budget_match else "Not found"

    # Contact Email
    email_match = re.search(r"[\w\.-]+@[\w\.-]+\.\w+", text)
    fields["contact_email"] = email_match.group(0) if email_match else "Not found"
    
    # Contact Phone
    phone_match = re.search(r"(\+?\d{1,3}[\s\-]?)?(\(?\d{3}\)?[\s\-]?)?\d{3}[\s\-]?\d{4}", text)
    fields["contact_phone"] = phone_match.group(0) if phone_match else "Not found"

    # Client Name
    client_match = re.search(r"(Purchaser|Client Name|Prepared For|Requesting Agency):\s*(.+)", text, re.IGNORECASE)
    fields["client_name"] = client_match.group(2).strip() if client_match else "Not found"

    # Scope of Work (basic match)
    scope_match = re.search(r"(Scope of Work|Description|Project Overview)\s*[:\-]?\s*(.*?)\n\n", text, re.IGNORECASE | re.DOTALL)
    fields["scope_of_work"] = scope_match.group(2).strip() if scope_match else "Not found"

    return fields

def extract_rfp_json(filepath):
    extension = os.path.splitext(filepath)[1].lower()
    if extension == ".pdf":
        text = extract_text_from_pdf(filepath)
    elif extension == ".docx":
        text = extract_text_from_docx(filepath)
    elif extension == ".txt":
        text = extract_text_from_txt(filepath)
    else:
        raise ValueError("Unsupported file type")

    return extract_fields(text)

# Example usage
if __name__ == "__main__":
    sample_path = "sample_rfp.pdf"  # Replace with your path
    extracted = extract_rfp_json(sample_path)
    print(json.dumps(extracted, indent=2))
