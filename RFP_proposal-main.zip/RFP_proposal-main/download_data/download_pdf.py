from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
import base64
import time
import os

# Setup output directory
output_dir = "data/rfps_commbuys"
os.makedirs(output_dir, exist_ok=True)

# List of bid URLs
# List of bid URLs (add more)
bid_urls = [

    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-24-1607-CONST-CONST-118703&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1045-BAW00-BAW01-118678&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1045-BAW00-BAW01-118676&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1531-SWSPD-SWSPD-118666&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1022-DMH08-8210C-118664&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1080-OSD03-SRC3-118659&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1150-CH015-CH015-118651&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1355-TYARM-YADPW-118645&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-19-1212-MWRA-DITP-118639&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1278-DPW15-DPW1-118638&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-18-1894-SVRV0-SVRV0-118635&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1795-MHA03-MHA03-118632&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-24-1806-MED05-MED05-118615&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1158-NBPT3-NBPT3-118750&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1144-CAMBR-CAMBR-118731&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1558-TMS01-TMS01-118711&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1160-02-02-118613&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1167-PUR02-PUR01-118896&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1167-PUR02-PUR01-118895&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-19-1371-NAPSK-NAPSK-118884&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1020-DCRFS-DC366-118872&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1035-DYS01-DYS01-118871&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1906-BHA02-BHA02-118868&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-22-1221-MOD00-MOD-118856&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1069-MILDV-30000-118851&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1326-DPW18-1-118848&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1154-PUCH1-PUCH1-118838&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1163-PD888-PD888-118829&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1342-WAY01-WAY01-118951&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1160-1160C-1160L-118942&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1109-UMAMH-AMH-118939&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1041-ENE01-ENE01-118921&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1286-PRC01-PRC01-118918&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1167-PUR02-PUR01-118916&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1167-PUR02-PUR01-118914&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1010-PROCU-CRIM-118806&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-17-1822-HA341-HA341-113326&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-17-1822-HA341-HA341-106572&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-17-1822-HA341-HA341-90045&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-17-1822-HA341-HA341-74712&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-17-1822-HA341-HA341-30088&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-17-1822-HA341-HA341-29663&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-17-1822-HA341-HA341-18465&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1031-TSH00-TSH01-118509&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1030-CPO1-CPO1-118137&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-24-2165-SPS04-SPS04-118126&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1021-DFS-DFS01-118071&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1019-DCP03-OFA01-118010&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1019-DCP03-OFA01-118009&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1019-DCP03-OFA01-118007&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1019-DCP03-OFA01-118004&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1019-DCP03-OFA01-118003&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1025-DOCCF-2016-117992&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-1060-ITD00-ITD00-117954&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1015-MPTCQ-MPTCQ-117949&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1015-MPTCQ-MPTCQ-117931&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1015-MPTCQ-MPTCQ-117925&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1060-ITD00-ITD00-117888&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1013-CAO00-FISCL-117872&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-26-2071-MO001-MO001-117847&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1076-OCDDE-HS003-117743&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1013-RFS00-REG00-117729&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1080-OSD10-OSD10-117727&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1100-EED01-EED01-117694&external=true&parentUrl=close",
    "https://www.commbuys.com/bso/external/bidDetail.sdo?docId=BD-25-1060-ITD00-ITD00-117679&external=true&parentUrl=close"   
   
    
]

# Setup Chrome options
options = Options()
options.add_argument('--headless')
options.add_argument('--disable-gpu')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--window-size=1920,1080')
options.add_experimental_option("prefs", {
    "printing.print_preview_sticky_settings.appState": '{"recentDestinations":[{"id":"Save as PDF","origin":"local"}]}',
    "savefile.default_directory": output_dir
})
options.add_argument('--kiosk-printing')

# Launch driver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Loop through each URL
for url in bid_urls:
    bid_id = url.split("docId=")[-1].split("&")[0]
    filename = f"{output_dir}/{bid_id}.pdf"
    print(f"Processing: {bid_id}")

    try:
        driver.get(url)
        time.sleep(5)  # Wait for page to load

        # Execute CDP command to print as PDF
        pdf = driver.execute_cdp_cmd("Page.printToPDF", {
            "landscape": False,
            "displayHeaderFooter": False,
            "printBackground": True
        })

        with open(filename, "wb") as f:
            f.write(base64.b64decode(pdf['data']))

        print(f"✅ Saved: {filename}")

    except Exception as e:
        print(f"❌ Failed to process {url}\nError: {e}")

driver.quit()
print("✅ All done.")
