from docx import Document  # For creating and editing .docx documents
from docx.shared import Pt  # For setting font size
from docx.oxml.ns import qn  # For XML namespace handling (used in adding custom styles)
from docx.oxml import OxmlElement  # For low-level XML editing (used for horizontal line)
import os  # For file system operations

def save_proposal_to_docx(title: str, proposal_text: str, rfp_input: dict) -> str:
    """
    Generates a .docx proposal document based on the given title, generated content,
    and input RFP metadata. Styles the document to be clean and professional.

    Parameters:
        title (str): The proposal title (used in heading and filename).
        proposal_text (str): The full proposal body text, potentially including section headers.
        rfp_input (dict): Metadata from the RFP (e.g., budget, deadline, contact info).

    Returns:
        str: Path to the saved .docx file.
    """
    # Create a new Word document
    doc = Document()

    # Set base font style (Segoe UI, 11pt)
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Segoe UI'
    font.size = Pt(11)

    # Title
    doc.add_heading(title, level=1)

    # Budget and Deadline only
    doc.add_paragraph(f"Budget: {rfp_input.get('budget', 'N/A')} | Deadline: {rfp_input.get('deadline', 'N/A')}")

    # Add horizontal line
    hr = doc.add_paragraph()
    p = hr._p
    p_pr = p.get_or_add_pPr()
    p_borders = OxmlElement("w:pBdr")
    bottom_border = OxmlElement("w:bottom")
    bottom_border.set(qn("w:val"), "single")
    bottom_border.set(qn("w:sz"), "6")
    bottom_border.set(qn("w:space"), "1")
    bottom_border.set(qn("w:color"), "999999")
    p_borders.append(bottom_border)
    p_pr.append(p_borders)

    # Line break
    doc.add_paragraph("\n")

    # Format proposal sections
    for line in proposal_text.strip().split("\n"):
        stripped = line.strip()
        if not stripped:
            continue

        # Detect section headers
        if any(stripped.lower().startswith(header.lower()) for header in [
            "Executive Summary", "Technical Approach", "Team", "Timeline", "Budget Overview", "Contact Info"]):
            section_heading = doc.add_heading(stripped, level=2)
            section_heading.paragraph_format.space_before = Pt(12)
            section_heading.paragraph_format.space_after = Pt(6)
        else:
            # Convert **bold** to real bold formatting with error protection
            para = doc.add_paragraph()
            while "**" in stripped:
                parts = stripped.split("**", 2)
                if len(parts) == 3:
                    before, bold_part, after = parts
                    para.add_run(before)
                    para.add_run(bold_part).bold = True
                    stripped = after
                else:
                    break
            para.add_run(stripped)

    # Add final contact info section if email or phone exists
# Add final contact info section only if it's not already in the text
    contact_email = rfp_input.get("contact_email", "")
    contact_phone = rfp_input.get("contact_phone", "")
    if (contact_email or contact_phone) and not any(keyword in proposal_text.lower() for keyword in ["contact info", "contact information", "contact details"]):

        doc.add_paragraph()
        doc.add_heading("Contact Information", level=2)
        contact_text = "Please feel free to contact us"
        if contact_email:
            contact_text += f" at {contact_email}"
        if contact_phone:
            contact_text += f" or {contact_phone}"
        contact_text += ". If you have any questions or would like additional information about our proposal."
        
         # Add contact message and closing
        doc.add_paragraph(contact_text)

        doc.add_paragraph("We look forward to the opportunity to collaborate on this exciting project.")
        doc.add_paragraph(f"Sincerely,\n{rfp_input.get('client_name', 'Your Team')}")


    # Save file
    os.makedirs("output", exist_ok=True)
    # Generate a safe filename using the title
    safe_title = title.replace(" ", "_").replace("/", "_")
    output_path = f"output/{safe_title}.docx"
    doc.save(output_path)
    return output_path
