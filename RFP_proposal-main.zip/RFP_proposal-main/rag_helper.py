# rag_helper.py

import faiss # type: ignore
import json
import numpy as np # type: ignore
from sentence_transformers import SentenceTransformer # type: ignore

# Paths
INDEX_PATH = "faiss_store/index.faiss"
METADATA_PATH = "faiss_store/metadata.json"
DATA_PATH = "data/rfp_data.json"

# Load FAISS index
index = faiss.read_index(INDEX_PATH)

# Load metadata (titles only, not required but good to keep)
with open(METADATA_PATH, "r") as f:
    metadata = json.load(f)

# Load full proposal data (used for retrieval)
with open(DATA_PATH, "r") as f:
    all_proposals = json.load(f)

# Load embedding model
model = SentenceTransformer("all-MiniLM-L6-v2")

#  Main retrieval function
def get_similar_examples(query_text: str, top_k: int = 2):
    """
    Returns top-k most similar proposals based on query_text using FAISS vector search.
    Each result is a full proposal dictionary from rfp_data.json.
    """
    # Convert query into vector embedding
    query_embedding = model.encode([query_text])
    # Search FAISS index for closest matches
    distances, indices = index.search(np.array(query_embedding), top_k)
    # Collect and return matching full proposals based on indices
    
    results = []
    for idx in indices[0]:
        if idx < len(all_proposals):
            results.append(all_proposals[idx])
    
    return results
