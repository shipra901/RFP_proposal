# proposal_evaluator.py

import json
import re

from llm import call_mistral  # your existing function

def evaluate_win_probability_llm(proposal_text, rfp_input):
    prompt = f"""
You are an RFP evaluation expert.

Based on the following proposal and RFP details, give a realistic win probability (0-100) and a short reason.

RFP Title: {rfp_input['title']}
Scope: {rfp_input['scope_of_work']}
Budget: {rfp_input['budget']}
Deadline: {rfp_input['deadline']}

--- Proposal ---
{proposal_text}

Respond in JSON like:
{{
  "win_probability": 0-100,
  "reason": "<1-2 sentence reason>"
}}
"""
    response = call_mistral(prompt)
    try:
        result = json.loads(response)
        return result.get("win_probability", 50), result.get("reason", "No reason provided.")
    except:
        return 50, "Could not parse win probability response."

def evaluate_quality_score_llm(proposal_text):
    prompt = f"""
You are a proposal reviewer.

Score this proposal from 0-100 on:
- Structure
- Clarity
- Professional tone
- Completeness

Respond in this JSON format:
{{
  "quality_score": 0-100,
  "reason": "<explanation in 1-2 lines>"
}}

Proposal:
{proposal_text}
"""
    response = call_mistral(prompt)
    try:
        result = json.loads(response)
        return result.get("quality_score", 50), result.get("reason", "No explanation provided.")
    except:
        return 50, "Could not parse quality score response."

def section_checklist(proposal_text):
    required_sections = ["Executive Summary", "Technical Approach", "Team", "Timeline", "Budget", "Contact"]
    present = []
    missing = []
    for section in required_sections:
        if re.search(section, proposal_text, re.IGNORECASE):
            present.append(section)
        else:
            missing.append(section)
    return present, missing

def readability_score(proposal_text):
    """
    Simple alternative to textstat:
    Calculates average sentence length as a proxy for readability.
    Lower is easier to read.
    """
    sentences = proposal_text.split(".")
    num_sentences = len([s for s in sentences if s.strip()])
    num_words = len(proposal_text.split())

    if num_sentences == 0:
        return "N/A"

    avg_words_per_sentence = num_words / num_sentences
    return round(100 - avg_words_per_sentence * 2, 2)  # Reverse score to mimic "ease"
