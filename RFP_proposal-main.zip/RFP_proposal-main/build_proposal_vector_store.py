# file: build_proposal_vector_store.py

import json
import faiss # Facebook AI Similarity Search for fast nearest neighbor search
import os
from sentence_transformers import SentenceTransformer
import numpy as np

# Load your 10 proposal samples
with open("data/rfp_data.json", "r") as f:
    proposals = json.load(f) # Load all past proposals (used for semantic similarity search)
    # Load Sentence Embedding Model

model = SentenceTransformer("all-MiniLM-L6-v2")

# Create text chunks to embed (combine all sections into one string)
texts = []
metadata = []
for idx, proposal in enumerate(proposals):
    # Create Embedding Text Chunks
    combined_text = (
        proposal.get("executive_summary", "") + " " +
        proposal.get("technical_approach", "") + " " +
        proposal.get("team", "") + " " +
        proposal.get("implementation_timeline", "") + " " +
        proposal.get("budget_overview", "")
    )

    texts.append(combined_text) # Add full proposal text to be embedded
    
    # Store metadata for future lookup (e.g., title or ID)
    metadata.append({"id": idx, "title": proposal.get("rfp", {}).get("title", f"Proposal {idx}")})


# Generate Embeddings
embeddings = model.encode(texts)# Convert each proposal's combined text into a dense vector


# Create FAISS index
dimension = embeddings.shape[1]  # Embedding dimension (e.g., 384 for MiniLM)
index = faiss.IndexFlatL2(dimension)  # L2 (Euclidean) distance index
index.add(np.array(embeddings))  # Add embeddings to the FAISS index

# Save index + metadata
os.makedirs("faiss_store", exist_ok=True)
# Save FAISS index file
faiss.write_index(index, "faiss_store/index.faiss")
# Save metadata (to identify results later)
with open("faiss_store/metadata.json", "w") as f:
    json.dump(metadata, f)

print("✅ FAISS vector store created!")
