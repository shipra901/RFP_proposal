import os
from openai import OpenAI # type: ignore # Import OpenAI client to interact with LLM via API
# Initialize the OpenAI client to connect with LM Studio running locally
client = OpenAI(
    base_url="http://localhost:1234/v1",  # LM Studio local API
    api_key="lm-studio"  # Dummy key required by OpenAI client
)

def call_mistral(prompt):
    response = client.chat.completions.create(
        model="local-model",  # Use whichever model is currently loaded in LM Studio
        messages=[
            {"role": "user", "content": prompt}  # Simulates a user prompt
        ],
        temperature=0.7,       # Controls randomness (higher = more creative)
        max_tokens=1024        # Limits length of generated response
    )
    
    # Extract and return the generated text
    return response.choices[0].message.content